#pragma once
static bool bLateGame = false;