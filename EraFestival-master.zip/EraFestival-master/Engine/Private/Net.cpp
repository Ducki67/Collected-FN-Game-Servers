#include "pch.h"
#include "Public/Net.h"
#include "Runtime.h"

int Net::GetNetMode()
{
    return 1;
}

void Net::TickFlush(UNetDriver* Driver)
{
	if (Driver->ReplicationDriver) ((void (*)(UReplicationDriver*))Offset::ServerReplicateActors)(Driver->ReplicationDriver);

	static bool bStartedEvent = false;

	if (GetAsyncKeyState(VK_F7)) 
	{
		auto EraScriptingClass = Runtime::FindObject<UClass>("/Game/fortmp/content_complex/domino/blueprints/domino_scripting.domino_scripting_C");
        if (!EraScriptingClass) {
            PLog("what the?");
            return;
        }
		
        auto Era = EraScriptingClass;

        auto StartEvent = Runtime::FindObject<UFunction>("/Game/fortmp/content_complex/domino/blueprints/domino_scripting.domino_scripting_C.StartEvent");
        PLog("StartEvent: ", StartEvent);
        struct StartEventParams {
            float _Maybe_StartTime;
        };
        StartEventParams Parms{};
        Parms._Maybe_StartTime = 0.f;
        Era->ProcessEvent(StartEvent, &Parms);

        PLog("Started event!");
        bStartedEvent = true;
	}

	return TickFlushOG(Driver);
}

float Net::GetMaxTickRate() {
    return 30.f;
}

void Net::ProcessEvent(const UObject* Object, void* pFunction, void* Parms)
{
	if (!pFunction) {
		PLog("Invalid FunctionPtr!");
		return;
	}

	UFunction* Function = static_cast<UFunction*>(pFunction);
	if (!Function) {
		PLog("Invalid UFunction!");
		return;
	}

	if (Function->GetFullName().contains("None")) {
		return;
	}

	if (Function->GetFullName().contains("domino_level.domino_level_C.ReceiveBeginPlay"))
	{
		return;
	}

	if (Function->GetName().contains("RequestGameServerData"))
	{
		return;
	}

	if (Function && Function->GetName().contains("FMP"))
	{
		auto KismetLib = Runtime::FindObject<UFortKismetLibrary>("/Script/FortniteGame.Default__FortKismetLibrary");
		if (KismetLib)
		{
			FText Message = UKismetTextLibrary::Conv_StringToText(L"hello world");
			return KismetLib->BroadcastMessage(nullptr, Message);
		}
	}

	return ProcessEventOG(Object, Function, Parms);
}

void* Net::DispatchRequest(UFortMcpProfile* Profile, UFortMcpContext* Context, __int64 a3)
{
	return DispatchRequestOG(Profile, Context, 3);
}

void Net::Hook()
{
	Runtime::Hook(Offset::ImageBase + Offsets::ProcessEvent, ProcessEvent, ProcessEventOG);
	Runtime::Hook(Offset::WorldNetMode, GetNetMode);
    Runtime::Hook(Offset::GetMaxTickRate, GetMaxTickRate);
    Runtime::Hook(Offset::TickFlush, TickFlush, TickFlushOG);
	Runtime::Hook(Offset::DispatchRequest, DispatchRequest, DispatchRequestOG);
}
