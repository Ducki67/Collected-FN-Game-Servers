#pragma once
#include "pch.h"

namespace Net {
	static int GetNetMode();
	DefHookOg(void, TickFlush, UNetDriver*);
	static float GetMaxTickRate();

	DefHookOg(void, ProcessEvent, const UObject*, void*, void*);

	DefHookOg(void*, DispatchRequest, UFortMcpProfile*, UFortMcpContext*, __int64);

	void Hook();
}