#include "pch.h"
#include "Public/FortAbilitySystemComponentAthena.h"
#include "Runtime.h"

void FortAbilitySystemComponentAthena::InternalServerTryActivateAbility(
    UFortAbilitySystemComponentAthena* AbilitySystemComponent, 
    FGameplayAbilitySpecHandle Handle, 
    bool InputPressed, 
    FPredictionKey& PredictionKey, 
    FGameplayEventData* TriggerEventData)
{
    auto Spec = AbilitySystemComponent->ActivatableAbilities.Items.Search(
        [&](FGameplayAbilitySpec& Item) { return Item.Handle.Handle == Handle.Handle; }
    );
    
    if (!Spec)
    {
        AbilitySystemComponent->ClientActivateAbilityFailed(Handle, PredictionKey.Current);
        return;
    }
    
    Spec->InputPressed = InputPressed;
    UGameplayAbility* InstancedAbility = nullptr;
    
    using TryActivateFunc = bool (*)(
        UAbilitySystemComponent*, 
        FGameplayAbilitySpecHandle, 
        FPredictionKey, 
        UGameplayAbility**, 
        void*, 
        const FGameplayEventData*
    );
    
    auto InternalTryActivate = reinterpret_cast<TryActivateFunc>(Offset::InternalTryActivateAbility);
    
    if (!InternalTryActivate(
        AbilitySystemComponent, 
        Handle, 
        PredictionKey, 
        &InstancedAbility, 
        nullptr, 
        TriggerEventData))
    {
        AbilitySystemComponent->ClientActivateAbilityFailed(Handle, PredictionKey.Current);
        Spec->InputPressed = false;
    }
    
    AbilitySystemComponent->ActivatableAbilities.MarkItemDirty(*Spec);
}

void FortAbilitySystemComponentAthena::GiveAbility(
    AFortPlayerControllerAthena* PlayerController, 
    UClass* Ability)
{
    if (!PlayerController || !PlayerController->PlayerState || !PlayerController->MyFortPawn || !Ability) {
        return;
    }

    auto ASC = PlayerController->MyFortPawn->AbilitySystemComponent;
    if (!ASC) {
        return;
    }

    FGameplayAbilitySpec Spec{};
    
    using ConstructSpecFunc = void (*)(
        FGameplayAbilitySpec*, 
        UGameplayAbility*, 
        int, 
        int, 
        UObject*
    );
    
    using GiveAbilityFunc = FGameplayAbilitySpecHandle* (__fastcall*)(
        UAbilitySystemComponent*, 
        FGameplayAbilitySpecHandle*, 
        FGameplayAbilitySpec
    );
    
    reinterpret_cast<ConstructSpecFunc>(Offset::ConstructAbilitySpec)(
        &Spec, 
        static_cast<UGameplayAbility*>(Ability->DefaultObject), 
        1, 
        -1, 
        nullptr
    );
    
    reinterpret_cast<GiveAbilityFunc>(Offset::InternalGiveAbility)(
        ASC, 
        &Spec.Handle, 
        Spec
    );
}
void FortAbilitySystemComponentAthena::GiveAbilitySet(AFortPlayerControllerAthena* PlayerController, UFortAbilitySet* Set)
{
    if (Set) for (auto Ability : Set->GameplayAbilities) GiveAbility(PlayerController, Ability);
}

void FortAbilitySystemComponentAthena::Hook()
{
	Runtime::Every<UFortAbilitySystemComponentAthena>(Offset::InternalServerTryActivateAbilityVft, &FortAbilitySystemComponentAthena::InternalServerTryActivateAbility);
}
