#include "pch.h"
#include "Public/FortGameModeAthena.h"
#include "Runtime.h"

bool FortGameModeAthena::ReadyToStartMatch(AFortGameModeAthena* GameMode)
{
    UFortPlaylistAthena* Playlist = nullptr;
    auto GameState = (AFortGameStateAthena*)GameMode->GameState;
    if (!Playlist) Playlist = Runtime::StaticFindObject<UFortPlaylistAthena>("/Game/Athena/Playlists/Music/Playlist_Music_High.Playlist_Music_High");

    static bool bInit = false;
    if (!bInit) {
        GameMode->WarmupRequiredPlayerCount = 1;

        GameState->CurrentPlaylistInfo.BasePlaylist = Playlist;
        GameState->CurrentPlaylistInfo.OverridePlaylist = Playlist;
        GameState->CurrentPlaylistInfo.PlaylistReplicationKey++;
        GameState->CurrentPlaylistInfo.MarkArrayDirty();
        GameState->OnRep_CurrentPlaylistInfo();
        GameMode->CurrentPlaylistId = Playlist->PlaylistId;
        GameState->CurrentPlaylistId = Playlist->PlaylistId;
        GameState->OnRep_CurrentPlaylistId();
        GameMode->CurrentPlaylistName = Playlist->PlaylistName;

        GameMode->GameSession->MaxPlayers = Playlist->MaxPlayers;

        GameState->AirCraftBehavior = Playlist->AirCraftBehavior;
        GameState->CachedSafeZoneStartUp = Playlist->SafeZoneStartUp;
        GameState->WorldLevel = Playlist->LootLevel;
		GameState->bGameModeWillSkipAircraft = Playlist->bSkipAircraft;
        bInit = true;
    }

//    if (!GameState->MapInfo) return false;

    auto WarmupActors = Runtime::GetAll<AFortPlayerStartWarmup>();

	int WarmupSpots = WarmupActors.Num();

	WarmupActors.Free();

    if (WarmupSpots == 0) return false;
	static bool ugh = false;
    if (WarmupSpots > 0) {
		if (!ugh) {
            GameState->OnRep_CurrentPlaylistInfo();
            GameState->OnRep_CurrentPlaylistId();
			ugh = true;
		}
    }
    
    if (!UWorld::GetWorld()->NetDriver)
    {
        using CreateNetDriverType = UNetDriver * (*)(UEngine*, UWorld*, FName);
        using InitListenType = bool (*)(UNetDriver*, UWorld*, FURL&, bool, FString&);
        using SetWorldType = void (*)(UNetDriver*, UWorld*);

        auto GND = UKismetStringLibrary::Conv_StringToName(L"GameNetDriver");
        auto NetDriver = ((CreateNetDriverType)Offset::CreateNetDriver)(UEngine::GetEngine(), UWorld::GetWorld(), GND);
        NetDriver->World = UWorld::GetWorld();
        NetDriver->NetDriverName = GND;

        UWorld::GetWorld()->NetDriver = NetDriver;
        for (auto& Collection : UWorld::GetWorld()->LevelCollections)
            Collection.NetDriver = NetDriver;

        FString Err;
        FURL URL;
        URL.Port = 7777;

        ((InitListenType)Offset::InitListen)(NetDriver, UWorld::GetWorld(), URL, false, Err);
        ((SetWorldType)Offset::SetWorld)(NetDriver, UWorld::GetWorld());
        SetConsoleTitleA("Tiva | Listening");
        GameMode->bWorldIsReady = true;
    }

	return GameMode->AlivePlayers.Num() > 0;
}

APawn* FortGameModeAthena::SpawnDefaultPawnFor(AFortGameModeAthena* GameMode, AFortPlayerControllerAthena* NewPlayer, AActor* StartSpot)
{
	auto Transform = StartSpot->GetTransform();
	Transform.Translation.Z += 250.f;
	auto Pawn = GameMode->SpawnDefaultPawnAtTransform(NewPlayer, Transform);

//	NewPlayer->AcknowledgedPawn = Pawn;

  //  ((AFortPlayerStateAthena*)NewPlayer->PlayerState)->HeroType = NewPlayer->CustomizationLoadout.Character->HeroDefinition;
    
	//static UFortAbilitySet* AbilitySet = Runtime::StaticFindObject<UFortAbilitySet>("/Game/Abilities/Player/Generic/Traits/DefaultPlayer/GAS_DefaultPlayer.GAS_DefaultPlayer");
	
//    FortAbilitySystemComponentAthena::GiveAbilitySet(PlayerController, AbilitySet);
//	_ApplyCharacterCustomization(NewPlayer->PlayerState, Pawn);

	return Pawn;
}

void FortGameModeAthena::HandleStartingNewPlayer(AGameModeBase* GameMode, AFortPlayerControllerAthena* NewPlayer)
{
	AFortGameStateAthena* GameState = (AFortGameStateAthena*)GameMode->GameState;
	AFortPlayerStateAthena* PlayerState = (AFortPlayerStateAthena*)NewPlayer->PlayerState;

           static auto Head = Runtime::StaticFindObject<UCustomCharacterPart>("/Game/Characters/CharacterParts/Female/Medium/Heads/F_Med_Head1.F_Med_Head1");
        static auto Body = Runtime::StaticFindObject<UCustomCharacterPart>("/Game/Characters/CharacterParts/Female/Medium/Bodies/F_Med_Soldier_01.F_Med_Soldier_01");

        PlayerState->CharacterParts.Parts[0] = Head;
        PlayerState->CharacterParts.Parts[1] = Body;
        PlayerState->OnRep_CharacterParts();

	PlayerState->SquadId = int32(PlayerState->TeamIndex) - 3;
	PlayerState->OnRep_SquadId();

	return HandleStartingNewPlayerOG(GameMode, NewPlayer);
}

void FortGameModeAthena::Hook()
{
    Runtime::Virtual<AFortGameModeAthena>(Offset::ReadyToStartMatchVft, ReadyToStartMatch, ReadyToStartMatchOG);
    Runtime::Virtual<AFortGameModeAthena>(Offset::SpawnDefaultPawnForVft, &SpawnDefaultPawnFor);
    Runtime::Virtual<AFortGameModeAthena>(Offset::HandleStartingNewPlayerVft, &HandleStartingNewPlayer, HandleStartingNewPlayerOG);
}
