#include "pch.h"
#include "Public/FortPlayerControllerAthena.h"
#include "Public/FortAbilitySystemComponentAthena.h"

void* (*_ApplyCharacterCustomization)(APlayerState*, APawn*) = decltype(_ApplyCharacterCustomization)(Offset::ApplyCharacterCustomization);

void FortPlayerControllerAthena::ServerAcknowledgePossession(AFortPlayerControllerAthena* PlayerController, APawn* Pawn)
{
	PlayerController->AcknowledgedPawn = Pawn;

	//((AFortPlayerStateAthena*)PlayerController->PlayerState)->HeroType = PlayerController->CustomizationLoadout.Character->HeroDefinition;
    
	static UFortAbilitySet* AbilitySet = Runtime::StaticFindObject<UFortAbilitySet>("/Game/Abilities/Player/Generic/Traits/DefaultPlayer/GAS_DefaultPlayer.GAS_DefaultPlayer");
	
    FortAbilitySystemComponentAthena::GiveAbilitySet(PlayerController, AbilitySet);
//	_ApplyCharacterCustomization(PlayerController->PlayerState, Pawn);
}

void FortPlayerControllerAthena::Hook()
{
	Runtime::Virtual<AFortPlayerControllerAthena>(Offset::ServerAcknowledgePossessionVft, ServerAcknowledgePossession);
}