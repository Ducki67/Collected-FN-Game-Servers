#pragma once
#include "pch.h"

namespace FortAbilitySystemComponentAthena {
	void GiveAbilitySet(AFortPlayerControllerAthena*, UFortAbilitySet*);
	void InternalServerTryActivateAbility(UFortAbilitySystemComponentAthena*, FGameplayAbilitySpecHandle, bool, FPredictionKey&, FGameplayEventData*);
	void GiveAbility(AFortPlayerControllerAthena*, UClass*);
	
	void Hook();
};