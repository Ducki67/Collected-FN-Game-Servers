#pragma once
#include "pch.h"

namespace FortGameModeAthena {
	DefHookOg(bool, ReadyToStartMatch, AFortGameModeAthena*);
	static APawn* SpawnDefaultPawnFor(AFortGameModeAthena* GameMode, AFortPlayerControllerAthena* NewPlayer, AActor* StartSpot);
	DefHookOg(void, HandleStartingNewPlayer, AGameModeBase*, AFortPlayerControllerAthena*);

	void Hook();
}