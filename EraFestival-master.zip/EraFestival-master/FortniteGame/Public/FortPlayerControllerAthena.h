#pragma once
#include "pch.h"
#include "Runtime.h"

namespace FortPlayerControllerAthena {
	void ServerAcknowledgePossession(AFortPlayerControllerAthena* PlayerController, APawn* Pawn);

	void Hook();
}