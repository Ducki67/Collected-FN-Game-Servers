#pragma once
#include <stdint.h>
#include <vector>

namespace Offset {
	inline uint64_t ImageBase = *(uint64_t*)(__readgsqword(0x60) + 0x10);
	inline uint64_t ReadyToStartMatch = ImageBase + 0xd517e0;
	inline uint64_t SpawnDefaultPawnFor = ImageBase + 0xd58fc0;
	inline uint64_t ServerAcknowledgePossession = ImageBase + 0x2b5120;
	inline uint64_t HandleStartingNewPlayer = ImageBase + 0x104eac0;
	inline uint64_t ServerExecuteInventoryItem = ImageBase + 0x2b5120;
	inline uint64_t ServerAttemptAircraftJump = ImageBase + 0xda6e40;
	inline uint64_t CreateNetDriver = ImageBase + 0x2c69d00;
	inline uint64_t InitHost = ImageBase + 0x4655e0;
	inline uint64_t PauseBeaconRequests = ImageBase + 0x1271240;
	inline uint64_t InitListen = ImageBase + 0x4659d0;
	inline uint64_t SetWorld = ImageBase + 0x29fbce0;
	inline uint64_t WorldNetMode = ImageBase + 0x2cd6a40;
	inline uint64_t GIsClient = ImageBase + 0x5a8ab39;
	inline uint64_t TickFlush = ImageBase + 0x29fc860;
	inline uint64_t GetMaxTickRate = ImageBase + 0x2c75fe0;
	inline uint64_t DispatchRequest = ImageBase + 0xa7d080;
	inline uint64_t StaticFindObject = ImageBase + 0x1b51790;
	inline uint64_t StaticLoadObject = ImageBase + 0x1b528f0;
	inline uint64_t ApplyCharacterCustomization = ImageBase + 0x14801d0;
	inline uint64_t InternalTryActivateAbility = ImageBase + 0x69d9e0;
	inline uint64_t InternalServerTryActivateAbility = ImageBase + 0x2b5120;
	inline uint64_t ServerReplicateActors = ImageBase + 0x1374fb0;
	inline uint64_t Realloc = ImageBase + 0x18d1060;
	inline uint64_t ConstructAbilitySpec = ImageBase + 0x6c2e20;
	inline uint64_t InternalGiveAbility = ImageBase + 0x69c150;
	inline uint64_t StartNewSafeZonePhase = ImageBase + 0xd5d940;
	inline uint64_t PickTeam = ImageBase + 0xd4e170;
	inline uint32_t ReadyToStartMatchVft = 0xfc;
	inline uint32_t SpawnDefaultPawnForVft = 0xc3;
	inline uint32_t ServerAcknowledgePossessionVft = 0x106;
	inline uint32_t HandleStartingNewPlayerVft = 0xc9;
	inline uint32_t ServerExecuteInventoryItemVft = 0x1f9; 
	inline uint32_t ServerAttemptAircraftJumpVft = 0x43f;
	inline uint32_t InternalServerTryActivateAbilityVft = 0xf5;
	inline uint64_t GameSessionPatch = ImageBase + 0xdb564d;
	inline uint64_t EncryptionPatch = ImageBase + 0x2cd94ae;

	inline std::vector<uint64_t> NullFuncs = { ImageBase + 0x24df7e0, ImageBase + 0x1061160, ImageBase + 0x1271620 };

	inline std::vector<uint64_t> RetTrueFuncs = { ImageBase + 0x28cade0  };
}
