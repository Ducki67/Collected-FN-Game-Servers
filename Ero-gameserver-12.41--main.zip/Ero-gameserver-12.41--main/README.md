![image](https://github.com/user-attachments/assets/8c265350-d49e-4e83-8a30-dc241624fe2f)


Ero gameserver s12 is some what of a rewrite of Eon gameserver thats fixes all the bugs/add stuff and makes its 1:1.

## Features

Every thing that fortnite had at that time 1:1 proper

proper looting and correct lootpool

Deadpool bus

Deadpool SupplyDrops

removed vaulted vehicles from spawning

fixed looting

added loot llamas

fixed chopper not spawning not spawning on shark poi

fixed exploding animation and fixed crash when spamming crash pads

fixed unlimited crash pads when deployed by using the bind to open them

fixed C4 stacking

added onscreen mats info

fixed launch pads not being able to be placed

added healing to builds

added working upgrade benches

fixed 3 guns spawning on factions chests instead of 2

added weapons boats

## Installation

1. Clone this repository or download it
2. you extract the sdk
3. Build the project using Visual Studio 2022
4. Run the server using [FN.AutoHost](https://github.com/Twin1dev/FN.AutoHost) made by Twin1dev.
## Contributing

Contributions are welcome! Feel free to create pull requests or report issues on the GitHub repository.

**Note**: Credits to eon for the base of the gameserver! 
