#pragma once

#include <algorithm>
#include <time.h>
#include <vector>
#include <unordered_map>
#include <functional>
#include <string>
#include <sstream>

namespace Cheats
{
    

    void InitCheats()
    {
        FN_LOG(LogInit, Log, "InitCheats Success!");
    }
}