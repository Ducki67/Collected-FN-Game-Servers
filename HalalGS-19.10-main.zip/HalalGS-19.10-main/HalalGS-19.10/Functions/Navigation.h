#pragma once

namespace Navigation
{
    

	void InitNavigation()
	{

	}
}