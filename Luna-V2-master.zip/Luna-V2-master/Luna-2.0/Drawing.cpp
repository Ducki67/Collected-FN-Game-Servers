#include "pch.h"
#include "Drawing.h"
#include "SDK.h"
#include "Framework.h"

std::string versionStr = "Luna V2: " + std::format("{:.02f}", FNVer);  
LPCSTR Drawing::lpWindowName = versionStr.c_str();
ImVec2 Drawing::vWindowSize = { 550, 450 };
ImGuiWindowFlags Drawing::WindowFlags = 0;
bool Drawing::bDraw = true;
bool enableFeature = false;
float adjustValue = 0.0f;
ImVec4 color = ImVec4(0.45f, 0.55f, 0.60f, 1.00f);

void Drawing::Active()
{
	bDraw = true;
}

bool Drawing::isActive()
{
	return bDraw == true;
}

void Drawing::Draw()
{
    if (isActive())
    {
        ImGui::SetNextWindowSize(vWindowSize, ImGuiCond_Once);
        ImGui::SetNextWindowBgAlpha(1.0f);
        ImGui::Begin(lpWindowName, &bDraw, WindowFlags);
        {
            if (ImGui::BeginTabBar("MainTabBar"))
            {
                if (ImGui::BeginTabItem("Main"))
                {
                    ImGui::Spacing();

                    if (!Framework::Started)
                    {
                        if (ImGui::Button("Start Server"))
                        {
                            Framework::Functions::Init();
                            Framework::Started = true;
                        }
                    }
                    else
                    {
                        if (!Framework::Listening)
                        {
                            ImGui::Text("[*] Starting Server");
                            const char* dots = &"...."[int(ImGui::GetTime() * 2) % 4];
                            ImGui::SameLine();
                            ImGui::TextUnformatted(dots);
                        }
                        else {
							ImGui::Text("Listening on port 7777");
                        }
                    }
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Game"))
                {
                    ImGui::Text("Game");
                    ImGui::EndTabItem();
                }
                
                if (ImGui::BeginTabItem("Players"))
                {
                    ImGui::Text("Players");
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("Developer"))
                {
                    ImGui::Text("Developer");
                    ImGui::EndTabItem();
                }

                ImGui::EndTabBar();
            }
        }
        ImGui::End();
    }

    #ifdef _WINDLL
    if (GetAsyncKeyState(VK_INSERT) & 1)
        bDraw = !bDraw;
    #endif
}
