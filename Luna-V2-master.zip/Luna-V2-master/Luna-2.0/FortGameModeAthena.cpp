#include "pch.h"
#include "finder.h"
#include "FortInventory.h"
#include "FortGameModeAthena.h"
#include "Framework.h"

bool FortGameModeAthena::ReadyToStartMatch(UObject* GameMode)
{
	static bool bSetPlaylist = false;
	static bool bInit = false;

	static auto Playlist = (UObject*)TUObjectArray::FindObject("Playlist_DefaultSolo");

	if (!bSetPlaylist) {
		bSetPlaylist = true;
		GameMode->Get<"WarmupRequiredPlayerCount", uint32>() = 1;

		if (FNVer >= 6.10) {
			auto CurrentPlaylistInfo = GameState->GetPtr<"CurrentPlaylistInfo", FFastArraySerializer>();

			StructGet(CurrentPlaylistInfo, "PlaylistPropertyArray", "BasePlaylist") = Playlist;
			StructGet(CurrentPlaylistInfo, "PlaylistPropertyArray", "OverridePlaylist") = Playlist;
			StructGet<uint32>(CurrentPlaylistInfo, "PlaylistPropertyArray", "PlaylistReplicationKey")++;
			CurrentPlaylistInfo->MarkArrayDirty();

			GameState->Get<"CurrentPlaylistId", uint32>() = Playlist->Get<"PlaylistId", uint32>();

			GameMode->Get<"CurrentPlaylistId", uint32>() = Playlist->Get<"PlaylistId", uint32>();
			GameMode->Get<"CurrentPlaylistName", FName>() = Playlist->Get<"PlaylistName", FName>();
			
			GameState->Call<"OnRep_CurrentPlaylistInfo">();
			GameState->Call<"OnRep_CurrentPlaylistId">();
		}
		else if (FNVer > 4.0) {
			GameState->Get<"CurrentPlaylistData">() = Playlist;
			GameState->Call<"OnRep_CurrentPlaylistData">();

			GameMode->Get<"CurrentPlaylistId", uint32>() = Playlist->Get<"PlaylistId", uint32>();
			GameMode->Get<"CurrentPlaylistName", FName>() = Playlist->Get<"PlaylistName", FName>();
		}
		else {
			GameState->Get<"CurrentPlaylistId", uint32>() = 0;
		}
	}

	auto WarmupStarts = GetAll<"FortPlayerStartWarmup">();
	auto WarmupCount = WarmupStarts.Num();
	WarmupStarts.Free();
	if (WarmupCount == 0) {
		ReadyToStartMatchOG(GameMode);
		return false;
	}

	if (FNVer >= 5.00 && !GameState->Get<"MapInfo">()) {
		ReadyToStartMatchOG(GameMode);
		return false;
	}

	if (!bInit) {
		bInit = true;

		UObject* NetDriver = nullptr;
		auto CreateNetDriver = Finder->CreateNetDriver();
		if (!CreateNetDriver) {
			Log("Getting NetDriver using beacon");
			auto Beacon = SpawnActor(TUObjectArray::FindObject<UClass>("FortOnlineBeaconHost"), FVector{}, FRotator{});
			if (!Beacon) {
				Log("Failed to spawn beacon!");
				return false;
			}
			Beacon->Get<"ListenPort", uint32>() = FNVer < 13.00 ? 7777 - 1 : 7777;

			((bool (*)(AActor*)) Finder->InitHost())(Beacon);
			((void (*)(AActor*, bool)) Finder->PauseBeaconRequests())(Beacon, false);

			NetDriver = Beacon->Get<"NetDriver">();
		}
		else {
			Log("Getting NetDriver using CreateNetDriver");
			NetDriver = ((UObject * (*)(UObject*, UObject*, FName)) CreateNetDriver)(Engine, World, Conv_StringToName(L"GameNetDriver"));
		}

		NetDriver->Get<"World">() = World;
		NetDriver->Get<"NetDriverName", FName>() = Conv_StringToName(L"GameNetDriver");
		World->Get<"NetDriver">() = NetDriver;

		GameMode->Get<"GameSession">()->Get<"MaxPlayers", uint32>() = Playlist && Playlist->Has<"MaxPlayers">() ? Playlist->Get<"MaxPlayers", uint32>() : 100;

		auto& LevelCollections = World->Get<"LevelCollections", TArray<void*>>();
		static int LevelCollectionSize = TUObjectArray::FindObject<UStruct>("LevelCollection")->GetPropertiesSize();
		*(UObject**)(__int64(LevelCollections.GetPtr(0, LevelCollectionSize)) + 0x10) = NetDriver;
		*(UObject**)(__int64(LevelCollections.GetPtr(1, LevelCollectionSize)) + 0x10) = NetDriver;

		if (GameState->Has<"AirCraftBehavior">() && Playlist && Playlist->Has<"AirCraftBehavior">()) GameState->Get<"AirCraftBehavior", uint8>() = Playlist->Get<"AirCraftBehavior", uint8>();
		if (GameState->Has<"CachedSafeZoneStartUp">() && Playlist && Playlist->Has<"AirCraftBehavior">()) GameState->Get<"CachedSafeZoneStartUp", uint8>() = Playlist->Get<"SafeZoneStartUp", uint8>();

		FURL url;
		url.Port = 7777 - (FNVer >= 13.00 ? 1 : 0);
		FString Err;

		((void (*)(UObject*, UObject*)) Finder->SetWorld())(NetDriver, World);

		if (((bool (*)(UObject*, void*, FURL&, bool, FString&)) Finder->InitListen())(NetDriver, World, url, false, Err)) {
			((void (*)(UObject*, UObject*)) Finder->SetWorld())(NetDriver, World);
			if (FNVer >= 9.40) {
				GameState->Call<"OnRep_CurrentPlaylistInfo">();
				GameState->Call<"OnRep_CurrentPlaylistId">();
			}
			Runtime::SetBitfield(GameMode->GetPtr<"bWorldIsReady", PlaceholderBitfield>(), 1, true);
			SetConsoleTitleA("Luna V2 | Listening on Port 7777");
			Log("Listening on port 7777!");
			Framework::Listening = true;
		}
	}

	auto Ret = ReadyToStartMatchOG(GameMode);
	return GameMode->Get<"AlivePlayers", TArray<UObject*>>().Num() > 0;
}

UObject* FortGameModeAthena::SpawnDefaultPawnFor(UObject* GameMode, UObject* NewPlayer, AActor* StartSpot)
{
	static const UClass* PlayerPawnClass = TUObjectArray::FindObject<UClass>("PlayerPawn_Athena_C");

	if (!PlayerPawnClass)
	{
		return nullptr;
	}

	if (GameMode)
	{
		GameMode->Get<"DefaultPawnClass", const UClass*>() = PlayerPawnClass;
	}
	else
	{
		return nullptr;
	}

	FTransform SpawnTransform = StartSpot ? StartSpot->GetTransform() : FTransform::FTransform();
	SpawnTransform.Translation.Z += 250.f;

	struct { UObject* NewPlayer; FTransform SpawnTransform; UObject* ReturnValue; }
	AGameModeBase_SpawnDefaultPawnAtTransform_Params{ NewPlayer, SpawnTransform };

	GameMode->Call<"SpawnDefaultPawnAtTransform">(&AGameModeBase_SpawnDefaultPawnAtTransform_Params);

	auto WorldInventory = NewPlayer->Get<"WorldInventory">();
	auto Inventory = WorldInventory->GetPtr<"Inventory", UScriptStruct>();

	//StructGet<TArray<UObject*>>(Inventory, "FortItemList", "ReplicatedEntries").ResetNum();
	//StructGet<TArray<UObject*>>(Inventory, "FortItemList", "ItemInstances").ResetNum();

	//for (auto& I : GameMode->Get<"StartingItems", TArray<UObject*>>())
	//{
	//	auto Count = I->Get<"Count", int>();
	//	auto Item = I->Get<"Item">();

	//	FortInventory::GiveItem(NewPlayer, I->Get<"Item">(), I->Get<"Count", int>(), 1, 1);
	//}

	if (FNVer <= 8.50) {
		auto CustomizationLoadout = NewPlayer->GetPtr<"CustomizationLoadout", UScriptStruct>();
		auto Pickaxe = StructGet(CustomizationLoadout, "FortAthenaLoadout", "Pickaxe");

		FortInventory::GiveItem(NewPlayer, Pickaxe->Get<"WeaponDefinition">(), 1, 1, 1);
	}
	else {
		auto CustomizationLoadout = NewPlayer->GetPtr<"CosmeticLoadoutPC", UScriptStruct>();
		auto Pickaxe = StructGet(CustomizationLoadout, "FortAthenaLoadout", "Pickaxe");

		FortInventory::GiveItem(NewPlayer, Pickaxe->Get<"WeaponDefinition">(), 1, 1, 1);
	}

	return AGameModeBase_SpawnDefaultPawnAtTransform_Params.ReturnValue;
}

void FortGameModeAthena::HandleStartingNewPlayer(UObject* GameMode, UObject* NewPlayer) 
{
	auto PlayerState = NewPlayer->Get<"PlayerState">();

	PlayerState->Get<"SquadId", int32>() = PlayerState->Get<"TeamIndex", int32>() - 3;
	PlayerState->Call<"OnRep_SquadId">();

	return HandleStartingNewPlayerOG(GameMode, NewPlayer);
}

void FortGameModeAthena::Hook()
{
	Runtime::Hook<"FortGameModeAthena", "ReadyToStartMatch">(ReadyToStartMatch, ReadyToStartMatchOG);
	Runtime::Hook<"FortGameModeAthena", "SpawnDefaultPawnFor">(SpawnDefaultPawnFor);
	Runtime::Hook<"FortGameModeAthena", "HandleStartingNewPlayer">(HandleStartingNewPlayer, HandleStartingNewPlayerOG);
}
