#pragma once
#include "pch.h"
#include "SDK.h"
#include "Runtime.h"

namespace FortGameModeAthena {
	DefHookOg(bool, ReadyToStartMatch, UObject*);

	UObject* SpawnDefaultPawnFor(UObject* GameMode, UObject* NewPlayer, AActor* StartSpot);

	DefHookOg(void, HandleStartingNewPlayer, UObject*, UObject*);

	void Hook();
}