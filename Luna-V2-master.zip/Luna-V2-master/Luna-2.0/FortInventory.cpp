#include "pch.h"
#include "FortInventory.h"

void FortInventory::Update(UObject* PlayerController, UObject* Entry)
{
    if (!PlayerController) return;
    auto WorldInventory = PlayerController->Get<"WorldInventory">();
    auto Inventory = WorldInventory->GetPtr<"Inventory", UScriptStruct>();
    Runtime::SetBitfield(WorldInventory->GetPtr<"bRequiresLocalUpdate", PlaceholderBitfield>(), 1, true);
    WorldInventory->Call<"HandleInventoryLocalUpdate">();

    if (Entry) {
        auto EntryPtr = reinterpret_cast<FFastArraySerializerItem*>(Entry);
        FFastArraySerializerItem& EntryRef = *EntryPtr; 
        ((FFastArraySerializer*)Inventory)->MarkItemDirty(EntryRef);
    }
    else {
        ((FFastArraySerializer*)Inventory)->MarkArrayDirty();
    }
}

UObject* FortInventory::GiveItem(UObject* PlayerController, UObject* Def, int Count, int LoadedAmmo, int Level)
{
    if (!PlayerController || !Def) return nullptr;
    struct FortItemDefinition_CreateTemporaryItemInstanceBP final
    {
    public:
        int32                                         Count;
        int32                                         Level;
        class UFortItem* ReturnValue;
    } Params{
        Count, Level
    };

    Def->Call<"CreateTemporaryItemInstanceBP">(&Params);

	Log(Def->Name.ToSDKString().c_str());
    UObject* Item = (UObject*)(Params.ReturnValue);

    if (!Item) return nullptr;

    Item->Call<"SetOwningControllerForTemporaryItem">(PlayerController);
    // Item->Get<"ItemEntry">()->Get<"LoadedAmmo">() = LoadedAmmo;

    auto WorldInventory = PlayerController->Get<"WorldInventory">();
    auto Inventory = WorldInventory->GetPtr<"Inventory", UScriptStruct>();

    auto ReplicatedEntries = StructGet<TArray<UObject*>>(Inventory, "FortItemList", "ReplicatedEntries");
    auto ItemInstances = StructGet<TArray<UObject*>>(Inventory, "FortItemList", "ItemInstances");

	Log("Item: %s", Item->Name.ToSDKString().c_str());

    auto FortItemEntry = TUObjectArray::FindObject<UClass>("FortItemEntry")->GetPropertiesSize();

    ReplicatedEntries.Add(Item->Get<"ItemEntry">(), FortItemEntry);
    ItemInstances.Add(Item);
    Update(PlayerController, Item->GetPtr<"ItemEntry", UObject>());
    return Item;
}