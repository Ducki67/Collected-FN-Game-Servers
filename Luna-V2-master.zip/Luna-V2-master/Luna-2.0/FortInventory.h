#pragma once 
#include "pch.h"
#include "SDK.h"
#include "Runtime.h"

namespace FortInventory {
	void Update(UObject* PlayerController, UObject* Entry);
	UObject* GiveItem(UObject* PlayerController, UObject* Def, int Count, int LoadedAmmo, int Level);


	void Hook();
}