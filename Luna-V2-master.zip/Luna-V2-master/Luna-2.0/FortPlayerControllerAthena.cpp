#include "pch.h"
#include "finder.h"
#include "FortPlayerControllerAthena.h"
#include "Runtime.h"

void* (*ApplyCharacterCustomization)(UObject*, UObject*) = decltype(ApplyCharacterCustomization)(Finder->ApplyCharacterCustomization());

void FortPlayerControllerAthena::ServerAcknowledgePossession(UObject* PlayerController, UObject* Pawn)
{
	PlayerController->Get<"AcknowledgedPawn", UObject*>() = Pawn;

	if (Finder->ApplyCharacterCustomization()) {
		ApplyCharacterCustomization(PlayerController->Get<"PlayerState", UObject*>(), Pawn);
	}
}

void FortPlayerControllerAthena::Hook()
{
	Runtime::Hook<"FortPlayerControllerAthena", "ServerAcknowledgePossession">(ServerAcknowledgePossession);
}
 