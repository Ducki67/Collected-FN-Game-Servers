#pragma once
#include "pch.h"
#include "SDK.h"

namespace FortPlayerControllerAthena {
	void ServerAcknowledgePossession(UObject* PlayerController, UObject* Pawn);

	void Hook();
}