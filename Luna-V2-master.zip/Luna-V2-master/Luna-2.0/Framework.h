#include "pch.h"

namespace Framework {
	inline bool Started = false;
	inline bool Listening = false;
	static bool AutoStart = false;

	namespace Functions {
		void Init();
	}
}