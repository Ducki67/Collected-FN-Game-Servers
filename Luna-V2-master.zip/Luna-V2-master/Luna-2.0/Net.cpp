#include "pch.h"
#include "Net.h"
#include "Runtime.h"
#include "finder.h"

void* Net::DispatchRequest(void* unknown_1, void* MCPData, int MCPCode)
{
	if (FNVer < 8.01) *(int*)(__int64(MCPData) + (FNVer < 4.2 ? 0x60 : 0x28)) = 3;
	return DispatchRequestOG(unknown_1, MCPData, 3);
}

float Net::GetMaxTickRate() {
	return 30.0f;
}

void Net::TickFlush(UObject* NetDriver)
{
	auto ReplicationDriver = NetDriver->Get<"ReplicationDriver">();
	if (ReplicationDriver) {
		static int VTOff = 0;
		if (!VTOff) {
			if (FNVer >= 2.5 && FNVer <= 4.5) VTOff = 0x53;
			else if (std::floor(FNVer) == 5) VTOff = 0x54;
			else if (FNVer >= 7.40 && FNVer < 8.40) VTOff = 0x57;
			else if (std::floor(FNVer) == 6 || std::floor(FNVer) >= 7 && std::floor(FNVer) <= 10) VTOff = 0x56;
			else if (FNVer >= 11 && FNVer <= 11.10) VTOff = 0x57;
			else if (FNVer == 11.30 || FNVer == 11.31) VTOff = 0x59;
			else if (std::floor(FNVer) == 11) VTOff = 0x5A;
			else if (std::floor(FNVer) == 12 || std::floor(FNVer) == 13) VTOff = 0x5D;
			else if (std::floor(FNVer) == 14 || FNVer <= 15.2) VTOff = 0x5E;
			else if (FNVer >= 15.3 && FNVer < 19) VTOff = 0x5F;
			else if (FNVer >= 19 && std::floor(FNVer) <= 20) VTOff = 0x66;
			else if (FNVer >= 21) VTOff = 0x67;
		}
		
		reinterpret_cast<void(*)(UObject*)>(ReplicationDriver->Vft[VTOff])(ReplicationDriver);
	}
	else {
		Log("Legacy replication");
	}

	return TickFlushOG(NetDriver);
}

void Net::ProcessEvent(const UObject* Object, void* pFunction, void* Parms)
{
	if (!pFunction) {
		Log("Invalid FunctionPtr!");
		return;
	}

	UFunction* Function = static_cast<UFunction*>(pFunction);
	if (!Function) {
		Log("Invalid UFunction!");
		return;
	}

	Log(Function->GetName().ToSDKString().c_str());

	return ProcessEventOG(Object, Function, Parms);
}

int Net::GetNetMode()
{
	return 1;
}

void Net::Hook()
{
	Runtime::Hook(Finder->TickFlush(), &TickFlush, TickFlushOG);
	Runtime::Hook(Finder->DispatchRequest(), &DispatchRequest, DispatchRequestOG);
	Runtime::Hook(Finder->GetMaxTickRate(), &GetMaxTickRate);
	Runtime::Hook(Finder->WorldNetMode(), &GetNetMode);
	//Runtime::Hook(Finder->ProcessEvent(), &ProcessEvent, ProcessEventOG);
}
