#pragma once
#include "pch.h"
#include "SDK.h"

namespace Net {
	float GetMaxTickRate();
	int GetNetMode();
	DefHookOg(void, TickFlush, UObject*);
	DefHookOg(void*, DispatchRequest, void*, void*, int);

	DefHookOg(void, ProcessEvent, const UObject*, void*, void*);

	void Hook();
}