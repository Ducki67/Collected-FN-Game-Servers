#pragma once
#include "pch.h"
#include "SDK.h"
#include "Minhook.h"

struct PlaceholderBitfield
{
	uint8_t First : 1;
	uint8_t Second : 1;
	uint8_t Third : 1;
	uint8_t Fourth : 1;
	uint8_t Fifth : 1;
	uint8_t Sixth : 1;
	uint8_t Seventh : 1;
	uint8_t Eighth : 1;
};

namespace Runtime {
   inline void* nullptrForHook = nullptr;
   
   template<typename T = void*>
   __forceinline void Hook(uintptr_t ptr, void* detour, T& og = nullptrForHook) {
       MH_CreateHook(LPVOID(ptr), detour, std::is_same_v<T, void*> ? nullptr : (LPVOID*)&og);
   }

   
   inline void SetBitfield(void* Addr, uint8_t FieldMask, bool NewVal)
   {
	   auto Bitfield = (PlaceholderBitfield*)Addr;

	   switch (FieldMask) {
	   case 0x1:
		   Bitfield->First = NewVal;
		   break;
	   case 0x2:
		   Bitfield->Second = NewVal;
		   break;
	   case 0x4:
		   Bitfield->Third = NewVal;
		   break;
	   case 0x8:
		   Bitfield->Fourth = NewVal;
		   break;
	   case 0x10:
		   Bitfield->Fifth = NewVal;
		   break;
	   case 0x20:
		   Bitfield->Sixth = NewVal;
		   break;
	   case 0x40:
		   Bitfield->Seventh = NewVal;
		   break;
	   case 0x80:
		   Bitfield->Eighth = NewVal;
		   break;
	   case 0xFF:
		   *(bool*)Bitfield = NewVal;
		   break;
	   default:
		   break;
	   }
   }

   template<DefaultObjChars ClassName, ConstexprString FuncName, typename T = void*>
   __forceinline void Hook(void* detour, T& og = nullptrForHook) {
       auto DefaultObj = GetDefaultObj<ClassName>();
       auto VTable = (void**)DefaultObj->Vft;
       int idx = DefaultObj->GetFunction(FuncName)->GetVTableIndex();
       if (!is_same_v<T, void*>)
           og = (T)VTable[idx];

       DWORD vpog;
       VirtualProtect(VTable + idx, 8, PAGE_EXECUTE_READWRITE, &vpog);
       VTable[idx] = detour;
       VirtualProtect(VTable + idx, 8, vpog, &vpog);
   }
   
   template<typename U, typename T = void*>
   __forceinline void Virtual(uint32_t idx, void* detour, T& og = nullptrForHook) {
       auto VTable = (void**)U::GetDefaultObj()->VTable;
       if (!std::is_same_v<T, void*>)
           og = (T)VTable[idx];
       DWORD vpog;
       VirtualProtect(VTable + idx, 8, PAGE_EXECUTE_READWRITE, &vpog);
       VTable[idx] = detour;
       VirtualProtect(VTable + idx, 8, vpog, &vpog);
   }

   template <typename _Is>
   static __forceinline void Patch(uintptr_t ptr, _Is byte) {
       DWORD og;
       VirtualProtect(LPVOID(ptr), sizeof(_Is), PAGE_EXECUTE_READWRITE, &og);
       *(_Is*)ptr = byte;
       VirtualProtect(LPVOID(ptr), sizeof(_Is), og, &og);
   }

   __forceinline static void VHook(void* Vt, uint32_t Ind, void* Detour) {
       void** vtable = static_cast<void**>(Vt);
       DWORD Vo;
       VirtualProtect(vtable + Ind, 8, PAGE_EXECUTE_READWRITE, &Vo);
       vtable[Ind] = Detour;
       VirtualProtect(vtable + Ind, 8, Vo, &Vo);
   }

   template <typename _Ot = void*>
   __forceinline static void Exec(const char* _Name, void* _Detour, _Ot& _Orig = nullptrForHook) {
       auto _Fn = const_cast<UFunction*>(TUObjectArray::FindObject<UFunction>(_Name));
       if (!_Fn) return;
       if (!std::is_same_v<_Ot, void*>)
           _Orig = (_Ot)_Fn->GetNativeFunc();
       _Fn->GetNativeFunc() = reinterpret_cast<void*>(_Detour);
   }

   template <typename _Ct>
   __forceinline static void Every(uint32_t Ind, void* Detour) {
       for (int i = 0; i < UObject::ObjectFlags->Num(); i++) {
           auto Obj = UObject::GObjects->GetByIndex(i);
           if (Obj && Obj->IsA(_Ct::StaticClass())) {
               VHook(Obj->VTable, Ind, Detour);
           }
       }
   }
}