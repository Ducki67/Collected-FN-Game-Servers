#include "pch.h"
#include "SDK.h"
#include "Ui.h"
#include "Framework.h"

void Main() {
	AllocConsole();
	FILE* f;
	freopen_s(&f, "CONOUT$", "w", stdout);
	Log("LogLuna: Display: Fortnite version: %.02f\n", FNVer);
	Log("Image base: ", ImageBase);

	if (Framework::AutoStart) {
		Framework::Functions::Init();
		Framework::Started = true;
	}
}

BOOL APIENTRY DllMain(HMODULE hModule,
	DWORD  ul_reason_for_call,
	LPVOID lpReserved
)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		thread(Main).detach();
		UI::hCurrentModule = hModule;
		CreateThread(nullptr, NULL, (LPTHREAD_START_ROUTINE)UI::Render, nullptr, NULL, nullptr);
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}