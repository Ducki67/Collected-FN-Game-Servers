// pch.h: This is a precompiled header file.
// Files listed below are compiled only once, improving build performance for future builds.
// This also affects IntelliSense performance, including code completion and many code browsing features.
// However, files listed here are ALL re-compiled if any one of them is updated between builds.
// Do not add files here that you will be updating frequently as this negates the performance advantage.

#ifndef PCH_H
#define PCH_H

#define WIN32_LEAN_AND_MEAN             
#include <windows.h>
#include <thread>
#include <string>
#include <format>
#include <vector>
#include <stdexcept>
#include <type_traits>
#include <intrin.h>
#include <source_location>
#include <DbgHelp.h>
#include <algorithm>
#include <functional>
#include <iostream>
#include <dwmapi.h>
#include <d3dcompiler.h>
#include <DirectXMath.h>
#include <tchar.h>
#include <TlHelp32.h>
#include "d3d11.h"
#include <array>
#include <map>
#pragma comment(lib, "Dbghelp.lib")
#include "memcury.h"

using namespace std;
typedef uint64_t uint64;
typedef uint32_t uint32;
typedef uint16_t uint16;
typedef uint8_t uint8;
typedef int64_t int64;
typedef int32_t int32;
typedef int16_t int16;
typedef int8_t int8;


#define DefHookOg(_Rt, _Name, ...) static inline _Rt (*_Name##OG)(##__VA_ARGS__); static _Rt _Name(##__VA_ARGS__); 
#define Log(...) do { \
    printf("[Luna V2] %s (%s:%d) --> ", __func__, __FILE__, __LINE__); \
    printf(__VA_ARGS__); \
    printf("\n"); \
} while(0)
#endif //PCH_H