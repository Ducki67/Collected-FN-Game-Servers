#pragma once

// Fortnite (4.5-CL-4159770) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Announce_LowHeath.Announce_LowHeath_C.UserConstructionScript
struct AAnnounce_LowHeath_C_UserConstructionScript_Params
{
};

// Function Announce_LowHeath.Announce_LowHeath_C.OnClientAnnouncementStart
struct AAnnounce_LowHeath_C_OnClientAnnouncementStart_Params
{
};

// Function Announce_LowHeath.Announce_LowHeath_C.ExecuteUbergraph_Announce_LowHeath
struct AAnnounce_LowHeath_C_ExecuteUbergraph_Announce_LowHeath_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
