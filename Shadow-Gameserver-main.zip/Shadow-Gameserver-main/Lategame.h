#pragma once
#include "framework.h"



void ApplyAllLategameShit();