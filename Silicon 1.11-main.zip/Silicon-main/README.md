# Silicon
Why did I make this? Idk.


Working Features:
MCP(sometimes)
Looting
Basic things(Inventory, Abilities)
Somewhat replication

Bugs:
Yes.