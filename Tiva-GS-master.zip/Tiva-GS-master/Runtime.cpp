#include "pch.h"
#include "Runtime.h"

namespace Runtime {
    UObject* (*StaticFindObject_Internal)(UClass* Class, UObject* Package, const wchar_t* OrigInName, bool ExactClass) = decltype(StaticFindObject_Internal)(_int64(Offset::StaticFindObject));
    UObject* (*StaticLoadObject_Internal)(UClass*, UObject*, const TCHAR*, const TCHAR*, uint32_t, UObject*, bool) = (UObject* (*)(UClass*, UObject*, const TCHAR*, const TCHAR*, uint32_t, UObject*, bool)) Offset::StaticLoadObject;
}

void FFrame::StepCompiledIn(void* const Result, bool ForceExplicitProp)
{
    if (Code && !ForceExplicitProp)
    {
        ((void (*)(FFrame*, UObject*, void* const))(Offset::ImageBase + 0x15920B0))(this, Object, Result);
    }
    else
    {
        UField* _Prop = PropertyChainForCompiledIn;
        PropertyChainForCompiledIn = _Prop->Next;
        ((void (*)(FFrame*, void* const, UField*))(Offset::ImageBase + 0x15920E0))(this, Result, _Prop);
    }
}


void FFrame::IncrementCode() {
    Code = (uint8_t*)(__int64(Code) + (bool)Code);
}