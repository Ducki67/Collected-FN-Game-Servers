#pragma once
#include "pch.h"
#define PI 3.14159265358979323846f

class FOutputDevice
{
public:
    bool bSuppressEventTag;
    bool bAutoEmitLineTerminator;
    uint8_t _Padding1[0x6];
};

class FFrame : public FOutputDevice
{
public:
    void** VTable;
    UFunction* Node;
    UObject* Object;
    uint8* Code;
    uint8* Locals;
    void* MostRecentProperty;
    uint8_t* MostRecentPropertyAddress;
    uint8_t _Padding1[0x40];
    UField* PropertyChainForCompiledIn;

public:
    void StepCompiledIn(void* const Result, bool ForceExplicitProp = false);

    template <typename T>
    T& StepCompiledInRef() {
        T TempVal{};
        MostRecentPropertyAddress = nullptr;

        if (Code)
        {
            ((void (*)(FFrame*, UObject*, void* const))(Offset::ImageBase + 0x15920B0))(this, Object, &TempVal);
        }
        else
        {
            UField* _Prop = PropertyChainForCompiledIn;
            PropertyChainForCompiledIn = _Prop->Next;
            ((void (*)(FFrame*, void* const, UField*))(Offset::ImageBase + 0x15920E0))(this, &TempVal, _Prop);
        }

        return MostRecentPropertyAddress ? *(T*)MostRecentPropertyAddress : TempVal;
    }

    void IncrementCode();
};

namespace Runtime {
   inline void* nullptrForHook = nullptr;
   
   template<typename T = void*>
   __forceinline void Hook(uintptr_t ptr, void* detour, T& og = nullptrForHook) {
       MH_CreateHook(LPVOID(ptr), detour, std::is_same_v<T, void*> ? nullptr : (LPVOID*)&og);
   }
   
   template<typename U, typename T = void*>
   __forceinline void Virtual(uint32_t idx, void* detour, T& og = nullptrForHook) {
       auto VTable = (void**)U::GetDefaultObj()->VTable;
       if (!std::is_same_v<T, void*>)
           og = (T)VTable[idx];
       DWORD vpog;
       VirtualProtect(VTable + idx, 8, PAGE_EXECUTE_READWRITE, &vpog);
       VTable[idx] = detour;
       VirtualProtect(VTable + idx, 8, vpog, &vpog);
   }

   inline AActor* SpawnActor(UClass* Class, SDK::FVector Loc, SDK::FRotator Rot = {}, AActor* Owner = nullptr) {
       SDK::FTransform Transform;
       Transform.Translation = Loc;
       
       float sp = sinf(Rot.Pitch * (PI / 180.0f));
       float cp = cosf(Rot.Pitch * (PI / 180.0f));
       float sy = sinf(Rot.Yaw * (PI / 180.0f));
       float cy = cosf(Rot.Yaw * (PI / 180.0f));
       float sr = sinf(Rot.Roll * (PI / 180.0f));
       float cr = cosf(Rot.Roll * (PI / 180.0f));
       
       Transform.Rotation.X = cr * sp * cy - sr * sy;
       Transform.Rotation.Y = -cr * sp * sy - sr * cy;
       Transform.Rotation.Z = -cr * cp * sr;
       Transform.Rotation.W = cr * cp * cr;
       Transform.Scale3D = SDK::FVector{1.0f, 1.0f, 1.0f};
       
       return UGameplayStatics::GetDefaultObj()->FinishSpawningActor(
           UGameplayStatics::GetDefaultObj()->BeginDeferredActorSpawnFromClass(
               UWorld::GetWorld(), Class, Transform, 
               ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn, Owner), 
           Transform);
   }

   inline AActor* SpawnActor(UClass* Class, FTransform Transform, AActor* Owner = nullptr) {
       return UGameplayStatics::GetDefaultObj()->FinishSpawningActor(
           UGameplayStatics::GetDefaultObj()->BeginDeferredActorSpawnFromClass(
               UWorld::GetWorld(), Class, Transform,
               ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn, Owner),
           Transform);
   }

   template<typename T = AActor>
   T* SpawnActorUnfinished(UClass* Class, FVector Loc, FRotator Rot = {}, AActor* Owner = nullptr) {
       FTransform Transform(Loc, Rot);
       return (T*)UGameplayStatics::GetDefaultObj()->BeginDeferredActorSpawnFromClass(
           UWorld::GetWorld(), Class, Transform,
           ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn, Owner);
   }

   template<typename T = AActor>
   T* FinishSpawnActor(AActor* Actor, FVector Loc, FRotator Rot) {
       FTransform Transform(Loc, Rot);
       return (T*)UGameplayStatics::GetDefaultObj()->FinishSpawningActor(Actor, Transform);
   }

   template<typename T = AActor>
   T* SpawnActor(UClass* Class, FVector Loc, FRotator Rot = {}, AActor* Owner = nullptr) {
       return (T*)SpawnActor(Class, Loc, Rot, Owner);
   }

   template<typename T = AActor>
   T* SpawnActor(UClass* Class, FTransform Transform, AActor* Owner = nullptr) {
       return (T*)SpawnActor(Class, Transform, Owner);
   }

   template<typename T>
   T* SpawnActor(FVector Loc, FRotator Rot = {}, AActor* Owner = nullptr) {
       return (T*)SpawnActor(T::StaticClass(), Loc, Rot, Owner);
   }

   template<typename T>
   T* SpawnActor(FTransform Transform, AActor* Owner = nullptr) {
       return (T*)SpawnActor(T::StaticClass(), Transform, Owner);
   }

   template <typename _Is>
   static __forceinline void Patch(uintptr_t ptr, _Is byte) {
       DWORD og;
       VirtualProtect(LPVOID(ptr), sizeof(_Is), PAGE_EXECUTE_READWRITE, &og);
       *(_Is*)ptr = byte;
       VirtualProtect(LPVOID(ptr), sizeof(_Is), og, &og);
   }

   template<typename T>
   TArray<T*> GetAll() {
       TArray<AActor*> ret;
       UGameplayStatics::GetAllActorsOfClass(UWorld::GetWorld(), T::StaticClass(), &ret);
       return *reinterpret_cast<TArray<T*>*>(&ret);
   }

   extern UObject* (*StaticFindObject_Internal)(UClass* Class, UObject* Package, const wchar_t* OrigInName, bool ExactClass);

   template <typename T>
   inline T* StaticFindObject(std::string ObjectPath, UClass* Class = UObject::StaticClass()) {
       return (T*)StaticFindObject_Internal(Class, nullptr, std::wstring(ObjectPath.begin(), ObjectPath.end()).c_str(), false);
   }

   extern UObject* (*StaticLoadObject_Internal)(UClass*, UObject*, const TCHAR*, const TCHAR*, uint32_t, UObject*, bool);

   template<typename T>
   inline T* StaticLoadObject(std::string name) {
       T* Object = StaticFindObject<T>(name);
       if (!Object) {
           auto Name = std::wstring(name.begin(), name.end()).c_str();
           UObject* BaseObject = StaticLoadObject_Internal(T::StaticClass(), nullptr, Name, nullptr, 0, nullptr, false);
           Object = static_cast<T*>(BaseObject);
       }
       return Object;
   }

   template <typename T>
   static inline T* Cast(UObject* Object) {
       return (Object && Object->IsA(T::StaticClass())) ? (T*)Object : nullptr;
   }

   __forceinline static void VHook(void* Vt, uint32_t Ind, void* Detour) {
       void** vtable = static_cast<void**>(Vt);
       DWORD Vo;
       VirtualProtect(vtable + Ind, 8, PAGE_EXECUTE_READWRITE, &Vo);
       vtable[Ind] = Detour;
       VirtualProtect(vtable + Ind, 8, Vo, &Vo);
   }

   template <typename _Ot = void*>
   __forceinline static void Exec(const char* _Name, void* _Detour, _Ot& _Orig = nullptrForHook) {
       auto _Fn = StaticFindObject<UFunction>(_Name);
       if (!_Fn) return;
       if (!std::is_same_v<_Ot, void*>)
           _Orig = (_Ot)_Fn->ExecFunction;
       _Fn->ExecFunction = reinterpret_cast<UFunction::FNativeFuncPtr>(_Detour);
   }

   template <typename _Ct>
   __forceinline static void Every(uint32_t Ind, void* Detour) {
       for (int i = 0; i < UObject::GObjects->Num(); i++) {
           auto Obj = UObject::GObjects->GetByIndex(i);
           if (Obj && Obj->IsA(_Ct::StaticClass())) {
               VHook(Obj->VTable, Ind, Detour);
           }
       }
   }
}